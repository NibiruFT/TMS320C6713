/*
 * ======== dma.c ========
 */
#include "AudioDMA.h" 

extern int dataReadyFlag;

int ping_rx_flag = 1;
int ping_tx_flag = 0;

unsigned int dst, src;


/*
 * ======= DMA_rxStart ========
 * Starts DMA channel 0 with autoinitialization
 */
void DMA_rxStart(unsigned int dst, int count)
{
    DMA0_SRC = DRR;                          /* set source address */
    DMA0_DST = dst;                          /* set dst address */ 
    DMA0_TXCNT = FRAMES_PER_BLOCK + count;   /* set transfer count */
    DMA0_PCNTL |= DMA_START_AUTO;            /* start block transfer */   
}


/*  
 * ======= DMA_txStart ======== *
 * Starts DMA channel 1 with autoinitialization
 */
void DMA_txStart(unsigned int src, int count)
{  
    DMA1_SRC = src;                          /* set src address */
    DMA1_DST = DXR;                          /* set dst address to DXR */
    DMA1_TXCNT = FRAMES_PER_BLOCK + count;   /* set transfer count */
    DMA1_PCNTL |= DMA_START_AUTO;            /* start block transfer */
}


/*
 * ======== DMArxCisr ========
 * Interrupt service routine for DMA channel 0
 */
interrupt void DMArxCisr(void)
{
    /* enable end-of-frame interrupt */
    DMA0_SCNTL = SCNTL_ENABLE;

    /* buffer is available for processing */
    dataReadyFlag = 1;
    
    /* ping_rx_flag starts at 1 and toggles with each interrupt */
    if(ping_rx_flag == 1)
       ping_rx_flag = 0;
    else
       ping_rx_flag = 1;   
}


/*
 * ======== DMAtxCisr ========
 * Interrupt service routine for DMA channel 1
 */
interrupt void DMAtxCisr(void)
{  
    /* Enable end-of-frame interrupt */
    DMA1_SCNTL = SCNTL_ENABLE;

    /* ping_tx_flag starts at 0 and toggles with each interrupt */
    if(ping_tx_flag == 1)
       ping_tx_flag = 0;
    else
       ping_tx_flag = 1;
}
