/*
 *  ======== init.c ========
 */
#include "AudioDMA.h"


static void enableCodec(void);  /* Configure Codec */
static void enableMcBSP0(void); /* Configure McBSP 0 */
static void enableDMA(void);    /* Configure McBSP 0 to use DMA */

extern cregister volatile unsigned int IFR;
extern cregister volatile unsigned int ICR;
extern cregister volatile unsigned int IER;    

extern unsigned int ping_RX[BUFSIZE];
extern unsigned int pong_RX[BUFSIZE];
extern unsigned int ping_TX[BUFSIZE];
extern unsigned int pong_TX[BUFSIZE];


/*
 * ======== initApplication ========
 * Initialize buffers and peripherals
 */
void initApplication(void)
{   
   int index;
   
   /* Initialize buffers */
   for(index=0; index < BUFSIZE; index++)
   {  
      ping_RX[index] = 0x00000000;
      pong_RX[index] = 0x00000000;
      ping_TX[index] = 0x00000000;
      pong_TX[index] = 0x00000000;
   }
    
    /* Configure Codec */
    enableCodec();
    
    /* Configure McBSP 0 */
    enableMcBSP0();

    /* Configure DMA */
    enableDMA();

    /* Unmute left/right DAC-to-mixer */
    SETREGCODEC(DAC_LEFT_CNTL, DAC_UNMUTE);
    SETREGCODEC(DAC_RIGHT_CNTL, DAC_UNMUTE);    
}


/*
 * ======== initInterrupts ========
 */
void initInterrupts(void)
{
  /* enable NMIE  */
   IER |= 0x00000002;
   
  /* enable GIE  */   
   CSR |= 0x00000001;
}


/*
 * ======== enableCodec ========
 */
static void enableCodec(void)
{
    /* Reset and enable codec */
    CPLD &= CODEC_DISABLE;
    CPLD |= CODEC_ENABLE;

    /* wait for codec to finish initialization */
    while(IAR & INIT_DONE);
    
    /* Enable mode 2 */
    SETBITMASKCODEC(MODE_CNTL, MODE2_ENABLE);

    /* Set codec Serial port format */
    SETREGCODEC(SP_CNTL, SP_32_ENABLE);

    /* Set capture format */
    SETREGCODEC(CDF_CNTL, CDF_S_L16);

    /* Set playback format and sample rate */
    SETREGCODEC(FS_PDF_CNTL, FS8_S_L16);

    /* Enable bits in PIO (programmed I/O) */
    SETREGCODEC(PIO_CNTL, PIO_ENABLE);

    /* Reset Mode Control Bit (MCE) */
    IAR &= MCE_RESET;
}


/*
 * ======== enableMcBSP0 ========
 */
static void enableMcBSP0(void)
{
    /* Disable serial port */
    SPCR = SPCR_DISABLE;

    /* Configure pin control register */
    PCR = PCR_SET;
    
    /* Configure receive control register */
    RCR = CR_32_SET;
    
    /* Configure transmit control register */
    XCR = CR_32_SET;

    /* Enable transmit and receive channels */
    MCR = MCR_SET;

    /* Put serial port in 'standby' and wait for frame synch */
    SPCR = SPCR_STANDBY;

    /* Clear the frame synch interrupt */
    ICR = MCSP_RXINT_BIT;

    /* Enable serial port */
    SPCR = SPCR_ENABLE_DMA;
}


/*
 * ======== enableDMA ========
 */
static void enableDMA(void)
{
    /* Clear DMA R/W STAT bits */
    DMA0_SCNTL = 0x00;
    DMA1_SCNTL = 0x00;
    
    /* Set DMA Primary Control Register */
    DMA0_PCNTL = PCNTL_STOP;
    DMA0_PCNTL = PCNTL_ENABLE_AUTO_0;        
    DMA1_PCNTL = PCNTL_STOP;
    DMA1_PCNTL = PCNTL_ENABLE_AUTO_1;

    /* Set DMA Secondary Control Register */
    DMA0_SCNTL = SCNTL_ENABLE;   /* end-of-frame interrupt  */
    DMA1_SCNTL = SCNTL_ENABLE;   /* end-of-frame interrupt  */
    
    /* Set DMA Global Registers for Autoinitialization */
    DMA_GIRA = (unsigned int)&pong_RX[0]
       - ((unsigned int)&ping_RX[0] + (DMA_FRAME_SIZE * sizeof(unsigned int)))
       + sizeof(unsigned int);       
    DMA_GIRA = (DMA_GIRA << 16) + sizeof(unsigned int);
    DMA_GIRB = (unsigned int)&pong_TX[0]
       - ((unsigned int)&ping_TX[0] + (DMA_FRAME_SIZE * sizeof(unsigned int)))
       + sizeof(unsigned int);       
    DMA_GIRB = (DMA_GIRB << 16) + sizeof(unsigned int);
    DMA_GARB = (unsigned int)&ping_RX[0];   /* Reload value for DMA0     */
    DMA_GARC = (unsigned int)&ping_TX[0];   /* Reload value for DMA1     */
    DMA_GRRA = 0x20000 + DMA_FRAME_SIZE;    /* two frames + count per frame */
    
    /* Reset SRC and DST address registers */
    DMA0_SRC = 0x00;
    DMA0_DST = 0x00;
    DMA1_SRC = 0x00;
    DMA1_DST = 0x00;
    
    /* Enable DMA-to-CPU interrupts */
    IER |= DMA0_RXINT_BIT;   /* INT 8 */
    IER |= DMA1_TXINT_BIT;   /* INT 9 */   
}

