/*
 * =========================
 *
 *    DSP/BIOS by Degrees
 *
 * ======== audio.c ========
 *
 */
#include <std.h>
#include <log.h>
#include <sts.h>
#include <clk.h>
#include <trc.h>
#include <rtdx.h>
#include <string.h>
#include <math.h>
#include "AudioDMA.h"

unsigned int ping_RX[BUFSIZE];
unsigned int ping_TX[BUFSIZE];
unsigned int pong_RX[BUFSIZE];
unsigned int pong_TX[BUFSIZE];

int volume = 1;
int average = 0;
int count = 0;
int accum = 0;

int dataReadyFlag = 0;

void processBuffer(void);
void generateSine(void);

/* LOG Object created by the Configuration Tool */
extern far LOG_Obj trace;
extern far STS_Obj stsSinMax;
extern far STS_Obj stsSinMin;
extern far STS_Obj stsLogPrintf;

/* RTDX channels structures (these are macro calls) */  
RTDX_CreateInputChannel(control_channel);
RTDX_CreateOutputChannel(status_channel);

/*
 * ======== main ========
 */
void main()
{
   int date = 25;
   float percent = 10.26;
   int time;
   
   // enable the RTDX control channels
   RTDX_enableInput(&control_channel);  
   RTDX_enableOutput(&status_channel);

   BIOS_start() ;
         
   /* This requires two LOG_printf() functions because
      LOG_Printf() has a limit of two parameters.  Refer to help or
      the DSP/BIOS User's Guide for details  */
      
   if (TRC_query(TRC_USER0) == 0)
   {
      time = CLK_gethtime();
      STS_set(&stsLogPrintf, time);
   }

   LOG_printf(&trace, "Why do computer scientists celebrate Halloween    and Christmas on the same day?\
   \nBecause oct %o  equals dec %d.\n", date, date);
            
   LOG_printf(&trace, "(%6.2f percent of the population gets this joke.)\n", percent);
   
   if (TRC_query(TRC_USER0) == 0)
   {  
      time = CLK_gethtime();
      STS_delta(&stsLogPrintf, time);
   }                                                    
   
   initApplication();   
//   initInterrupts();
    
   /* Start DMA with autoinitialization */
   DMA_rxStart((unsigned int)&ping_RX[0], DMA_FRAME_SIZE);
   DMA_txStart((unsigned int)&ping_RX[0], DMA_FRAME_SIZE);   

   LOG_printf(&trace, "DMA started.\n");
     
   while(1)
   {
      if(dataReadyFlag)
      {
         dataReadyFlag = 0;
         processBuffer();
      }
      IDL_run();
   }
}


/*
 * ======== processBuffer ========
 * Copy full RX buffer to available TX buffer using memcpy()
 */
void processBuffer(void)
{  
   extern int ping_tx_flag;
   extern int ping_rx_flag;
   int index;
   int total = 0;
   short  *src, *dst;

      
   if(ping_rx_flag == 1)
      src = (short *)&pong_RX[0];
   else
      src = (short *)&ping_RX[0];
      
   if(ping_tx_flag == 1)
      dst = (short *)&pong_TX[0];
   else
      dst = (short *)&ping_TX[0];
         
   for(index = 0; index < DMA_FRAME_SIZE * 2; index++)
   {  
      *dst++ = (*src++ * volume);
      if(*dst < 0)
      {
         total += ~(*dst + 1);
      }
      else
      {
         total += (*dst);
      }

   }
   count++;
   accum = accum + (total / (DMA_FRAME_SIZE * 2));
   if(count == 10)
   {
      average = accum/count; 
      RTDX_write(&status_channel, &average, sizeof(int));
      count = 0;
      accum = 0;
   }
}


/*
 * ======== generateSine ========
 * Sine Wave Generator.  Applicable in Degree2
 */
void generateSine(void)
{
   double sinValue;
   double radian = 0;
   int index = 0;
   
   for(index = 0; index < 100; index ++){
      sinValue = sin(radian);
      STS_add(&stsSinMax, (1000 * sinValue));
      STS_add(&stsSinMin, -(1000 * sinValue));
      radian = radian + PI/90;
   }
}

/*
 *  ======== RTDXcommandHandler ========
 *
 * This function is called from the IDL Module to handle RTDX
 * commands sent from the Host
 *
 */
void RTDXcommandHandler()
{
   static unsigned int control, opCode;
   static unsigned int rxInt = 0;    

   /* Read new load control when host sends it */
   if (!RTDX_channelBusy(&control_channel))
   {
      // read integer from control channel
      RTDX_readNB(&control_channel, &rxInt, sizeof(rxInt));

      // opcode and data (control) are packed together into one
      // 32bit word
		    opCode = rxInt>>24;             
		
      control = (int)(rxInt & 0x00ffffff);

      switch(opCode)
      {
         case VOLUMEOPCODE:		       // 0x70
  volume = control;
           break;
                                                  
         default:
            LOG_printf(&trace, "Recv Unknown RTDX: OpCode = 0x%02x, Control = %d", opCode, control);                 
       			  break;
        	}
    }         
}
