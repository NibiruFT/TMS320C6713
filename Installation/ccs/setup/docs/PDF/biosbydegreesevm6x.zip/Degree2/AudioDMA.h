/*
 * ======== AudioDMA.h ========
 */
#ifndef AUDIODMA_
#define AUDIODMA_

#define DMA_FRAME_SIZE	0x0400
#define BUFSIZE		0x500
#define FRAMES_PER_BLOCK  0x00020000

#define PI 3.1415927

#define VOLUMEOPCODE      0x70

/* Macros */
#define SETBITMASKCODEC(i,n)\
              IAR = (i);\
	      IDR |= (n);
	      
#define SETREGCODEC(i,n)\
              IAR = (i);\
	      IDR = (n);

/* Control Registers */
extern cregister volatile unsigned int CSR;    /* Control Status Register    */
extern cregister volatile unsigned int IER;    /* Interrupt Enable Register  */

/* Memory Map 1 */

/* DMA Global Address Registers */
#define DMA_GARA   (*(volatile unsigned int *)0x01840038)
#define DMA_GARB   (*(volatile unsigned int *)0x0184003C)
#define DMA_GARC   (*(volatile unsigned int *)0x01840068)
#define DMA_GARD   (*(volatile unsigned int *)0x0184006C)
#define DMA_GRRA   (*(volatile unsigned int *)0x01840028)
#define DMA_GRRB   (*(volatile unsigned int *)0x0184002C)

/* DMA Global Index Registers  */
#define DMA_GIRA   (*(volatile unsigned int *)0x01840030)
#define DMA_GIRB   (*(volatile unsigned int *)0x01840034)

/* DMA0 Memory Mapped Registers */
#define DMA0_PCNTL (*(volatile unsigned int *)0x01840000) /* Pri cntl Reg */
#define DMA0_SCNTL (*(volatile unsigned int *)0x01840008) /* Sec cntl Reg */
#define DMA0_SRC   (*(volatile unsigned int *)0x01840010) /* Src Addr Reg */
#define DMA0_DST   (*(volatile unsigned int *)0x01840018) /* Dst Addr Reg */
#define DMA0_TXCNT (*(volatile unsigned int *)0x01840020) /* Transf Cnt Reg */

/* DMA1 Memory Mapped Registers */
#define DMA1_PCNTL (*(volatile unsigned int *)0x01840040) /* Pri cntl Reg */
#define DMA1_SCNTL (*(volatile unsigned int *)0x01840048) /* Sec cntl Reg */
#define DMA1_SRC   (*(volatile unsigned int *)0x01840050) /* Src Addr Reg */
#define DMA1_DST   (*(volatile unsigned int *)0x01840058) /* Dst Addr Reg */
#define DMA1_TXCNT (*(volatile unsigned int *)0x01840060) /* Transf Cnt Reg */

/* DMA Commands */
#define PCNTL_STOP     0x00        /* Stop DMA channel */
#define PCNTL_ENABLE_0 0x02034040  /* No auto-init, dst++, SP 0 rx int */
#define PCNTL_ENABLE_1 0x02600010  /* No auto-init, src++, SP 0 tx int */
#define PCNTL_ENABLE_AUTO_0 0x420340C0   /* Auto-init  */
#define PCNTL_ENABLE_AUTO_1 0x22036030   /* Auto-init   */
#define SCNTL_ENABLE   0x08        /* Enable end-of-frame interrupt */
#define SCNTL_BLOCK_ENABLE 0x80    /* Enable end-of-block interrupt */
#define DMA_START      0x01        /* Start without auto-init */
#define DMA_START_AUTO 0x03        /* Start with auto-init */

/* DMA Interrupts */
#define DMA0_RXINT_BIT 0x0100      /* DMA0 rx interrupt on INT 8 */
#define DMA1_TXINT_BIT 0x0200      /* DMA1 tx interrupt on INT 9 */

/* McBSP 0 Memory Mapped Registers */
#define DRR  0x018c0000              /* McBSP0 rx register */
#define DXR  0x018c0004              /* McBSP0 tx register */
#define SPCR (*(volatile unsigned int *)0x018c0008) /* Serial Port Cont Reg */
#define RCR  (*(volatile unsigned int *)0x018c000c) /* Receive Control Reg */
#define XCR  (*(volatile unsigned int *)0x018c0010) /* Transmit Control Reg */
#define MCR  (*(volatile unsigned int *)0x018c0018) /* Multichannel Reg */
#define PCR  (*(volatile unsigned int *)0x018c0024) /* Pin Control Reg */

/* CPLD (Complex Programmable Logic Device) Register */
#define CPLD (*(volatile unsigned int *)0x01780000)

/* Codec Memory Mapped Registers */
#define IAR  (*(volatile unsigned int *)0x01720000) /* Index Address Reg */
#define IDR  (*(volatile unsigned int *)0x01720004) /* Indexed Data Reg */
#define SR   (*(volatile unsigned int *)0x01720008) /* Status Reg */
#define PIO  (*(volatile unsigned int *)0x0172000c) /* PIO Data Reg */

/* Codec Indirect Mapped Registers */
#define DAC_LEFT_CNTL   0x06  /* I6  - Left DAC Output Control */
#define DAC_RIGHT_CNTL  0x07  /* I7  - Right DAC Output Control */
#define FS_PDF_CNTL     0x48  /* I8  - FS & Playback Data Control (MCE set) */
#define PIO_CNTL        0x49  /* I9  - Interface Control (MCE set) */
#define MODE_CNTL       0x0c  /* I12 - Mode and ID Control */
#define SP_CNTL         0x50  /* I16 - Alternate Feature enable 1 (MCE set) */
#define LINE_LEFT_CNTL  0x12  /* I18 - Left Line Input Control */
#define LINE_RIGHT_CNTL 0x13  /* I19 - Right Line Input Control */
#define CDF_CNTL        0x5c  /* I28 - Capture Data Format (MCE set)*/

/* Codec Commands */
#define DAC_UNMUTE    0x00  /* Unmute DAC-to-mixer */
#define MODE2_ENABLE  0x40  /* Enable MODE 2 */
#define INIT_DONE     0x80  /* Initialization bit */
#define SP_32_ENABLE  0x0a  /* Serial Port (32 bits) */
#define SP_64E_ENABLE 0x02  /* Serial Port (64 bits enhanced) */
#define SP_64_ENABLE  0x06  /* Serial Port (64 bits enhanced) */
#define CDF_S_L16     0x50  /* CDF; Stereo, linear, 16-bit */
#define FS8_S_L16     0x50  /* FS: 8kHz, PDF; Stereo, linear, 16-bit */
#define FS44_S_L16    0x5c  /* FS: 44kHz, PDF; Stereo, linear, 16-bit */
#define PIO_ENABLE    0xc3  /* Enable PIO (capture and playback) */
#define MCE_RESET     0xbf  /* Reset Mode Control Bit (MCE) */

/* CPLD Commands */
#define CODEC_DISABLE  0xf8
#define CODEC_ENABLE   0x04

/* McBSP 0 Commands */
#define SPCR_DISABLE    0x00        /* Disable serial port */
#define SPCR_STANDBY    0x00200020  /* Wait for frame synch, enable RX int */
#define SPCR_ENABLE     0x00010001  /* enable serial port (interrupt CPU) */
#define SPCR_ENABLE_DMA 0x00110011  /* enable serial port (!interrupt CPU)*/
#define PCR_SET         0x00        /* external RX/TX clock and frame synch */
#define CR_32_SET       0x000000a0  /* 32 bit word, 1 w/frame, single phase */
#define CR_SET          0x000101a0  /* 32 bit word, 2 w/frame, single phase */
#define MCR_SET         0x00        /* enable TX and RX channels */
#define MCSP_RXINT_BIT  0x0800      /* assume serial RX interrupt on INT 11 */

#endif


