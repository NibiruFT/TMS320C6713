/*
 * =========================
 *
 *    DSP/BIOS by Degrees
 *
 * ======== audio.c ========
 *
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "AudioDMA.h"

unsigned int ping_RX[BUFSIZE];
unsigned int ping_TX[BUFSIZE];
unsigned int pong_RX[BUFSIZE];
unsigned int pong_TX[BUFSIZE];

int dataReadyFlag = 0;

void processBuffer(void);
void generateSine(void);


/*
 * ======== main ========
 */
void main()
{
   int date = 25;
   float percent = 10.26;
         
   printf("Why do computer scientists celebrate Halloween and Christmas on the same day?\
       \nBecause oct %o equals dec %d.  (%6.2f percent of the population gets this joke)\n",
        date, date, percent);   

   initApplication();   
   initInterrupts();
    
   /* Start DMA with autoinitialization */
   DMA_rxStart((unsigned int)&ping_RX[0], DMA_FRAME_SIZE);
   DMA_txStart((unsigned int)&ping_RX[0], DMA_FRAME_SIZE);   

   printf("DMA started.\n");
     
   while(1)
   {
      if(dataReadyFlag)
      {
         dataReadyFlag = 0;
         processBuffer();
      }
   }
}


/*
 * ======== processBuffer ========
 * Copy full RX buffer to available TX buffer using memcpy()
 */
void processBuffer(void)
{  
   extern int ping_tx_flag;
   extern int ping_rx_flag;
   char  *src, *dst;
      
   if(ping_rx_flag == 1)
      src = (char *)&pong_RX[0];
   else
      src = (char *)&ping_RX[0];
      
   if(ping_tx_flag == 1)
      dst = (char *)&pong_TX[0];
   else
      dst = (char *)&ping_TX[0];
      
   memcpy(dst, src, DMA_FRAME_SIZE*sizeof(unsigned int));
}


/*
 * ======== generateSine ========
 * Sine Wave Generator.  Applicable in Degree2
 */
void generateSine(void)
{
   double sinValue;
   double radian = 0;
   int index = 0;
   
   for(index = 0; index < 100; index ++){
      sinValue = sin(radian);
      radian = radian + PI/90;
   }
}
