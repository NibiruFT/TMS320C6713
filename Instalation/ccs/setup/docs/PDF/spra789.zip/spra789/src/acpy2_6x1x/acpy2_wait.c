/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_wait.c ========
 */
 
#pragma CODE_SECTION(ACPY2_wait, ".text:ACPY2_wait")

#include <std.h>
 
#include <csl_edma.h>

#include <_acpy2.h>
#include <idma2_priv.h>

/*
 * ======== ACPY2_wait ======== 
 * wait for the data transfers to complete
 */
Void ACPY2_wait(IDMA2_Handle handle)
{               
    Uint32 mask = 1 << (handle->lastTCC);
        
    /*
     * If the entry in the table corresponding to the last TCC
     * used by this handle matches the handle itself, then we need 
     * to wait for the TCC bit to get set to ensure transfer completion.
     * Otherwise, the TCC has already been assigned to a subsequent
     * transfer, meaning the last transfer on this handle has already
     * completed, and there is no need to wait.
     */
    if (_ACPY2_TCCTable[handle->lastTCC] == handle) {
        //This loop will not get optimized out because EDMA_RGET(CIPR)
        //macro maps into (volatile)(address_of_CIPR)
        while ((EDMA_RGET(CIPR) & mask) != mask) {
            ;
        }
    }
}



