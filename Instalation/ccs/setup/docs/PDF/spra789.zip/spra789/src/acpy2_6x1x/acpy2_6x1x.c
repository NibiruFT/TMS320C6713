/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_6x1x.c ========
 *  ACPY2_6X1X default instance creation parameters
 */
 
#include <std.h>

#include <idma2_priv.h>
#include <acpy2_6x1x.h>

/*
 *  ======== ACPY2_6X1X ========
 *  This static initialization defines the default parameters used to
 *  initialize the ACPY2 library.
 */
ACPY2_6X1X_Config ACPY2_6X1X = {
    3,                  // 3 TCCs are reserved for ACPY2's use 
};

