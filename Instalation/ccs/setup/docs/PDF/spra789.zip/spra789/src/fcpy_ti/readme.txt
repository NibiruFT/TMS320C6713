TITLE
-----
XDAIS FCPY algorithm 

DESCRIPTION
-----------
The FCPY module is a 2D buffer copying algorithm. It takes an input
buffer, and copies it to an output buffer using DMA.

FILES
-----
- fcpy*.pjt: project files for building a library for the appropriate
       architecture
- fcpy_ti.c: implementation of VOL_TI_init,exit() functions
- fcpy_ti_ifcpy: implementation of the volume changing function
- fcpy_ti_ialg.c: implementation of IALG functions for the algorithm       
- fcpy_ti_ifcpyvt.c: definition of the virtual table for the algorithm
- fcpy_ti_idma2.c: implementation of IDMA2 functions for the algorithm
- fcpy_ti_idma2vt.c: definition of the virtual table for the IDMA2 interface
- fcpy_ti_priv.h: declaration of private algorithm object structure
- ../include/fcpy_ti.h: declaration of FCPY filter function names
- ../include/ifcpy.h: FCPY interface definition
- readme.txt: this file

NOTE
----
Files in the library are compiled with no optimization switches turned on,
and the same is true for the project files. If you plan to use this module 
in a product release, it is advised that you rebuild the library with 
optimization turned on. 

An ACPY2 library implementation must be linked with the algorithm for it to work.

Q&A
---
Q1: Is there any value in using this algorithm in my application?
Q2: Why are the parameters srcLineLen and srcNumLines read only?
Q3: Why am I seeing unexpected output data?

---
Q1: Is there any value in using this algorithm in my application?
A1: No. The algorithm is designed to show how to use the IDMA2 interface and
 the ACPY2 APIs to perform different types of DMA transfers in XDAIS 
 algorithms.

---
Q2: Why are the parameters srcLineLen and srcNumLines read only?
A2: They are read only because they determine the size of the internal scratch 
 buffers used in the algorithm.

---
Q3: Why am I seeing unexpected output data?
A3: Make sure srcLineLen * srcNumLines = dstLineLen * dstNumLines, to ensure 
 all input data is transferred to the output buffer.

 


