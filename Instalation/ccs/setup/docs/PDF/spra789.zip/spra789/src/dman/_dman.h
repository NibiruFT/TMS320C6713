/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/* 
 *  ======== _dman.h ======== 
 *  Private declarations for DMAN module
 */

#ifndef _DMAN_
#define _DMAN_

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

#define _DMAN_MAXDMARECS 16   // Maximum number of DMA handles for an algorithm

extern Int _DMAN_heapId;      // Heap used by DMAN to allocate logical channels

extern Void _DMAN_freeChannels(IDMA2_ChannelRec dmaTab[], Int numChan);

#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif /*_DMAN_*/


