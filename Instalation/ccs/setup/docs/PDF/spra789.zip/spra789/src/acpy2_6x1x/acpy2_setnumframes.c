/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
#pragma CODE_SECTION(ACPY2_setNumFrames, ".text:ACPY2_setNumFrames")

#include <std.h>

#include <csl_edma.h>

#include <idma2_priv.h>

/*
 *  ======== ACPY2_setNumFrames ======== 
 *  Rapidly configure the numFrames parameter of an IDMA2 channel
 */
 
Void ACPY2_setNumFrames(IDMA2_Handle handle, Uns numFrames)
{
    handle->params.numFrames = numFrames;
    handle->config.cnt = EDMA_FMK(CNT,FRMCNT,
        ((handle->params.numFrames) - 1));  
}


