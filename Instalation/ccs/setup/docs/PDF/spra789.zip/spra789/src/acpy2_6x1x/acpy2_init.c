/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_init.c ========
 */
 
#pragma CODE_SECTION(ACPY2_init, ".text:ACPY2_init")

#pragma DATA_SECTION(_ACPY2_TCCTable, ".bss:_ACPY2_TCCTable")

#include <std.h> 
#include <sys.h>

#include <csl_edma.h>

#include <_acpy2.h>
#include <acpy2_6x1x.h>
#include <idma2_priv.h>

//Table recording which handle last used a particular TCC
IDMA2_Handle _ACPY2_TCCTable[_ACPY2_TCCTABLESIZE] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};              
    
Int _ACPY2_TCCmask = 0;  //Bits in CIPR reserved for ACPY2's use
Char _ACPY2_TCCsAllocated[_ACPY2_TCCTABLESIZE] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };

/*
 * ======== ACPY2_init ======== 
 * Initialize the ACPY2 module
 *
 * The strategy consists of setting the TCC bits allocated for ACPY2
 *    using dummy transfers.  In this manner, when ACPY2_start is called,
 *    the transfer can take ownernership of one of the TCC bits set, and
 *    reset it.  ACPY2_wait can then wait on the TCC bit to get set again
 *    to ensure transfer completion. 
 */
Void ACPY2_init(Void) 
{
    Int count = 0;
 
    //Used for dummy transfers to set CIPR register used in QDMA transfers.
    Uint32 dummySrc;
    Uint32 dummyDst;
    EDMA_Config dummyCfg;
        
    //if ACPY2_init has never been called before 
    if (_ACPY2_TCCmask == 0) { 
        
        //Initialize dummyCfg structure    
        dummyCfg.opt = EDMA_FMKS(OPT,PRI,HIGH) |
            EDMA_FMKS(OPT,ESIZE,8BIT) |
            EDMA_FMKS(OPT,2DS,NO) |
            EDMA_FMKS(OPT,SUM,INC) |
            EDMA_FMKS(OPT,2DD,NO) |
            EDMA_FMKS(OPT,DUM,INC) |
            EDMA_FMKS(OPT,TCINT,YES) |
            EDMA_FMKS(OPT,TCC,OF(0)) |    
            EDMA_FMKS(OPT,LINK,NO) |
            EDMA_FMKS(OPT,FS,YES);        

        dummyCfg.src = (Uint32)&dummySrc;
        dummyCfg.cnt = 0x4;  //Transfer 4 bytes to fill dummyDst (arbitrary #)
        dummyCfg.dst = (Uint32)&dummyDst;
        dummyCfg.idx = 0;       
                        
        //Allocate the TCCs for ACPY2.
        for (count = 0; count < ACPY2_6X1X.numTCC; count++) {
            _ACPY2_TCCsAllocated[count] = EDMA_intAlloc(-1);
            if (_ACPY2_TCCsAllocated[count] == -1) {
                SYS_abort("Not enough TCCs available");
            }
            else if (_ACPY2_TCCsAllocated[count] >= _ACPY2_TCCTABLESIZE) {
                /*
                 * NOTE: On C64x, if EDMA_intAlloc returns a TCC value that is 
                 * not supported on the C6211, this implementation will fail
                 * since it is built to work with C6211.  It simply maintains
                 * compatibility with C64x devices.
                 */
                SYS_abort("TCC returned exceeds the maximum TCC supported" \
                    "by this implementation.");
            }

            _ACPY2_TCCmask |= (1 << _ACPY2_TCCsAllocated[count]);   
            
            /* 
             * Do a dummy transfer so that bits in CIPR register are set, 
             * meaning TCCs are ready for another transfer
             */
            EDMA_FSETA(&(dummyCfg.opt), OPT, TCC, _ACPY2_TCCsAllocated[count]);     
            EDMA_qdmaConfig(&dummyCfg);
        }
    }  
}



