/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== dman_setup.c ========
 *  Function for setting up the heap used in DMAN 
 */

#pragma CODE_SECTION(DMAN_setup, ".text:create");

#include <std.h>

#include <dman.h>

Int _DMAN_heapId;

/*
 *  ======== DMAN_setup ======== 
 *  Setup the DMAN module.  Specifies the heap ID for dynamic
 *  allocation.  This function is called when initializing the DMAN
 *  module.  In a dynamic system, it can also be called to change the heap
 *  used by DMAN after all algorithms have been removed from DMAN using
 *  DMAN_removeAlg. 
 */
Void DMAN_setup(Int heapId) 
{
    /* Assumed heapId to be a valid segment address */
    _DMAN_heapId = heapId;
}




