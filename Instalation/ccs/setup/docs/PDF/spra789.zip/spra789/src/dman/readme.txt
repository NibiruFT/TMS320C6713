TITLE
-----
DMAN (DMA Manager) module

DESCRIPTION
-----------
DMAN is a module used to manage DMA resource allocation for XDAIS algorithms.

FILES
-----
Each DMAN function is placed in a separate file to avoid dead code, unless 
two or more functions are always dependent; in that case, they are placed
together in a single source file.

- dman*.pjt: project files for building a library for the appropriate
      architecture
- _dman.h: DMAN private global variables and declarations
- dman_addalg.c: DMAN_addAlg() function
- dman_exit.c: DMAN_exit() function
- dman_init.c: DMAN_init() function
- dman_remalg.c: DMAN_removeAlg() function
- dman_setup.c: DMAN_setup() function
- ../include/dman.h: public header file for the DMAN module
- readme.txt: this file

NOTE
----
Files in the library are compiled with no optimization switches turned on,
and the same is true for the project files. If you plan to use this module 
in a product release, it is advised that you rebuild the library with 
optimization turned on.

An ACPY2 library for the appropriate architecture must be linked with the DMAN
module for it to work.

Q&A
---
Q1: When is the DMAN module needed?

---
Q1: When is the DMAN module needed?
A1: Only when there are XDAIS algorithms that implements the IDMA2 interface in the 
 application.  Otherwise, it is not necessary to include it in the system.  
