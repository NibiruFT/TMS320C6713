TITLE
-----
FASTCOPYTEST example for C6211/6711

DESCRIPTION
-----------
This example shows how to make a copy of a large buffer using 4 calls to the FCPY_TI algorithm, 
which uses the ACPY2 library to perform its DMA transfers.

FILES
-----
- fastcopytest62.pjt: project file for building the example 
- fastcopytest.cmd: linker command file
- fastcopytest.c: example code
- fastcopytest.cdb: DSP/BIOS cdb file used in this example
- fcpy.h: header file used to expose functions of the FCPY module
- fcpy.c: implementation of FCPY wrapper APIs
- ifcpy.c: file containing FCPY's default parameters
- readme.txt: this file


Q&A
---
Q1: What is the expected output?
Q2: Why are we calling FCPY algorithm 4 times instead of once to copy the entire buffer?

---
Q1: What is the expected output?
A1: If the program runs successfully, the word "pass" would appear in the DSP/BIOS Message 
Log.

Q2: Why are we calling FCPY algorithm 4 times instead of just onceto copy the entire buffer?
A2: This is just an example to show how to call into an algorithm that uses DMA.  We have
chosen to make multiple calls to FCPY to make the example more interesting (somewhat).

   
 