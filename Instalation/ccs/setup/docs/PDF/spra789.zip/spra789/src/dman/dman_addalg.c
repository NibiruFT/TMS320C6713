/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== dman_addalg.c ========
 *  Grant logical channel resources to an algorithm instance
 */

#pragma CODE_SECTION(DMAN_addAlg, ".text:create");
#pragma CODE_SECTION(allocChannels, ".text:create");
#pragma CODE_SECTION(_DMAN_freeChannels, ".text:create");

#include <std.h>
#include <mem.h>

#include <dman.h>
#include <_dman.h>
#include <acpy2.h>

static Bool allocChannels(IDMA2_ChannelRec dmaTab[], Int n);

/* 
 *  ======== DMAN_addAlg ======== 
 *  Add an algorithm to the DMA Manager.  The DMA Manager will grant DMA
 *  resources to the algorithm as a result.  This function is called when 
 *  initializing an algorithm instance.
 */
Bool DMAN_addAlg(IALG_Handle algHandle, IDMA2_Fxns *dmaFxns)
{
    Int numChan;
    IDMA2_ChannelRec dmaTab[_DMAN_MAXDMARECS];
    
    /* verify that alg and idma2 fxns are from same implementation */
    if ((algHandle != NULL) && (dmaFxns != NULL) &&
        (dmaFxns->implementationId == algHandle->fxns->implementationId)) {

        numChan = dmaFxns->dmaGetChannelCnt();

        /* 
         *  Stack-based dmaTab records avoid the risk of fragmentation.
         *  A maximum number of records is set.  If, in the unlikely case,
         *  more records than the maximum are requested, return failure
         */
        if (numChan > _DMAN_MAXDMARECS) {
            return (FALSE);
        }
                                        
        numChan = dmaFxns->dmaGetChannels(algHandle, dmaTab);
        if (numChan <= 0) {
            return (FALSE);
        }

        if (allocChannels(dmaTab, numChan) == TRUE) {
            if (dmaFxns->dmaInit(algHandle, dmaTab) == IALG_EOK) {
                return (TRUE);  // DMA init success
            }
            /* If dmaInit fails for any reason, free channel resources */
            _DMAN_freeChannels(dmaTab, numChan);
        }
    }
    return (FALSE);
}

/*
 *  ======== allocChannels ========
 *  Allocate and initialize logical channels (IDMA2_Obj's) requested in 
 *  a dmaTab[]. 
 */
static Bool allocChannels(IDMA2_ChannelRec dmaTab[], Int numChan)
{
    Int i;
    Int chanObjSize = ACPY2_getChanObjSize();
    
    for (i = 0; i < numChan; i++) {
        /* 
         * Word alignment is done to help simplify accesses of fields  
         * in the IDMA2_Obj structure by assembly implementations of ACPY2
         */
        dmaTab[i].handle = (IDMA2_Handle)MEM_alloc(_DMAN_heapId, chanObjSize, 
            sizeof (Int));  
        if (dmaTab[i].handle == MEM_ILLEGAL) {
            _DMAN_freeChannels(dmaTab, i);
            return (FALSE);
        }
        
        /* Initialize channel object */
        ACPY2_initChannel(dmaTab[i].handle, dmaTab[i].queueId);              
    }
       
    return (TRUE);
}

/*
 *  ======== freeChannels ========
 *  Reclaim logical channel resources (IDMA2_Obj's). 
 */
Void _DMAN_freeChannels(IDMA2_ChannelRec dmaTab[], Int numChan)
{
    Int i;
    Int chanObjSize = ACPY2_getChanObjSize();    

    for (i = 0; i < numChan; i++) {
        if (dmaTab[i].handle != MEM_ILLEGAL) {
            MEM_free(_DMAN_heapId, dmaTab[i].handle, chanObjSize);
        }
    }
    
    return;
}


