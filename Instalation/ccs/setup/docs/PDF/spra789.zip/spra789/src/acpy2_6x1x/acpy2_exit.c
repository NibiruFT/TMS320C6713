/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== acpy2_exit.c ========
 */

#pragma CODE_SECTION(ACPY2_exit, ".text:ACPY2_exit")

#include <std.h>

#include <csl_edma.h>

#include <acpy2_6x1x.h>
#include <_acpy2.h> 

Void ACPY2_exit(Void)
{
    int count;
    
    //Free TCCs allocated by ACPY2
    for (count = 0; count < ACPY2_6X1X.numTCC; count++) {
        EDMA_intFree(_ACPY2_TCCsAllocated[count]);
    }
}


