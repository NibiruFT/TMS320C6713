/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/*
 *  ======== dman_remalg.c ========
 *  Function for removing logical channel resources from an 
 *  algorithm instance
 */

#pragma CODE_SECTION(DMAN_removeAlg, ".text:delete");
 
#include <std.h>

#include <dman.h>
#include <_dman.h>

/* 
 *  ======== DMAN_removeAlg ======== 
 *  Remove logical channel resources from an algorithm instance. 
 *  This function is called before deallocating an algorithm instance
 *  in dynamic systems. 
 */
Bool DMAN_removeAlg(IALG_Handle algHandle, IDMA2_Fxns *dmaFxns)
{
    IDMA2_ChannelRec dmaTab[_DMAN_MAXDMARECS];
    Int numChan;
    Int actualNumChan;
        
    /* verify that alg and idma2 fxns are from same implementation */
    if ((algHandle != NULL) && (dmaFxns != NULL) &&
        (dmaFxns->implementationId == algHandle->fxns->implementationId)) {

        numChan = dmaFxns->dmaGetChannelCnt();

        /* 
         *  Stack-based dmaTab records reduces fragmentation.
         *  A maximum number of records is set.  If, in the unlikely case,
         *  more records than the maximum are requested, return failure
         */
        if (numChan > _DMAN_MAXDMARECS) {
            return (FALSE);
        }
                                        
        actualNumChan = dmaFxns->dmaGetChannels(algHandle, dmaTab);
        if (actualNumChan <= 0) {
            return (FALSE);
        }
            
        _DMAN_freeChannels(dmaTab, actualNumChan);
             
        return (TRUE);
    }
    return (FALSE);
}



