/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
#pragma CODE_SECTION(ACPY2_setDstFrameIndex, ".text:ACPY2_setDstFrameIndex")

#include <std.h>

#include <csl_edma.h>

#include <idma2_priv.h>

/*
 *  ======== ACPY2_setDstFrameIndex ======== 
 *  Rapidly configure the destination frame index parameter of an 
 *  IDMA2 channel.  Note that both source and destination indexes
 *  are set simultaneously on the C6x1x with this API.
 */
Void ACPY2_setDstFrameIndex(IDMA2_Handle handle, Int frameIndex)
{
    handle->params.dstFrameIndex = frameIndex;

    /*
     * For 2D to 2D transfers, src and dst indices must be set to same
     * value.
     */
    if (handle->params.xType == IDMA2_2D2D) {
        handle->params.srcFrameIndex = frameIndex;
    }   
        
    /*
     * The idx register value is recomputed
     */
    handle->config.idx &= 0x0000FFFF;  //clear the frame index field
    handle->config.idx |= 
        EDMA_FMK(IDX,FRMIDX,(handle->params.dstFrameIndex)); 
}


