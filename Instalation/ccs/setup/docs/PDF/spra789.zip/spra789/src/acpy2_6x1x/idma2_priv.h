/*
 *  Copyright 2002 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *  
 */
/* "@(#) XDAS 2.5.11 10-11-02 (xdas-d15)" */
/* 
 * ======== idma2_priv.h ======== 
 * Header file for IDMA2 channel structure used in the DMAN and ACPY2 modules
 *
 */

#ifndef IDMA2_PRIV_
#define IDMA2_PRIV_

#include <csl_edma.h>

#include <idma2.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

/*
 * IDMA2_Obj is the structure representation of a logical DMA channel.  It 
 * contains the state information of the channel
 */ 
typedef struct IDMA2_Obj {
    IDMA2_Params params;     // Used to hold the current channel config params    
    Int lastTCC;            // The last TCC used by this channel in decimal
    EDMA_Config config;     // Config structure used to store QDMA parameters 
                            // before writing them to registers
} IDMA2_Obj;

#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif /*IDMA2_PRIV_*/


